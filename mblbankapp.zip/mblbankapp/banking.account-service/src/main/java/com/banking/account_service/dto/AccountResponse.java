package com.banking.account_service.dto;


public class AccountResponse {

    private String accountNumber;
    private String fullName;
    private String phoneNumber;
    private String address;
    private Double balance;

    public AccountResponse() {}

    public AccountResponse(String accountNumber, String fullName,
                           String phoneNumber, String address, Double balance) {
        this.accountNumber = accountNumber;
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.balance = balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getFullName() {
        return fullName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public Double getBalance() {
        return balance;
    }
}

