package com.banking.account_service.service;

import java.util.UUID;

import org.springframework.stereotype.Service;

import com.banking.account_service.dto.AccountResponse;
import com.banking.account_service.dto.CreateAccountRequest;
import com.banking.account_service.entity.Account;
import com.banking.account_service.exception.AccountNotFoundException;
import com.banking.account_service.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public AccountResponse createAccount(CreateAccountRequest request) {

        String accountNumber = generateAccountNumber();

        Account account = new Account(
                accountNumber,
                request.getUserId(),
                request.getFullName(),
                request.getPhoneNumber(),
                request.getAddress(),
                request.getInitialBalance()
        );

        Account saved = accountRepository.save(account);

        return new AccountResponse(
                saved.getAccountNumber(),
                saved.getFullName(),
                saved.getPhoneNumber(),
                saved.getAddress(),
                saved.getBalance()
        );
    }

    @Override
    public AccountResponse getAccountByNumber(String accountNumber) {

        Account account = accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new AccountNotFoundException("Account not found"));

        return new AccountResponse(
                account.getAccountNumber(),
                account.getFullName(),
                account.getPhoneNumber(),
                account.getAddress(),
                account.getBalance()
        );
    }

    private String generateAccountNumber() {
        return "ACC-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase();
    }
}
