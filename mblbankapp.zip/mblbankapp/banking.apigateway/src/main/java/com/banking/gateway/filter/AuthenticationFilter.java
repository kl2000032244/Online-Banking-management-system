package com.banking.gateway.filter;







import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import com.banking.gateway.util.JwtUtil;

import io.jsonwebtoken.Claims;
import reactor.core.publisher.Mono;

@Component
public class AuthenticationFilter
        extends AbstractGatewayFilterFactory<AuthenticationFilter.Config> {

    @Autowired
    private RouteValidator routeValidator;

    @Autowired
    private JwtUtil jwtUtil;

    public AuthenticationFilter() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {

            if (routeValidator.isSecured.test(exchange.getRequest())) {

                // 1️⃣ Check Authorization header
                if (!exchange.getRequest().getHeaders()
                        .containsKey(HttpHeaders.AUTHORIZATION)) {
                    return onError(exchange, "Missing Authorization Header");
                }

                String authHeader =
                        exchange.getRequest()
                                .getHeaders()
                                .getFirst(HttpHeaders.AUTHORIZATION);

                if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                    return onError(exchange, "Invalid Authorization Header");
                }

                String token = authHeader.substring(7);

                try {
                    // 2️⃣ Validate token
                    jwtUtil.validateToken(token);

                    // 3️⃣ Extract claims
                    Claims claims = jwtUtil.extractClaims(token);
                    String role = claims.get("role", String.class);

                    // 4️⃣ ROLE BASED ACCESS
                    String path = exchange.getRequest().getURI().getPath();

                    if (path.startsWith("/accounts/admin")
                            && !"ROLE_ADMIN".equals(role)) {
                        return onError(exchange, "ADMIN access only");
                    }

                } catch (Exception e) {
                    return onError(exchange, "Invalid or expired token");
                }
            }

            return chain.filter(exchange);
        };
    }

    private Mono<Void> onError(ServerWebExchange exchange, String message) {
        exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
        return exchange.getResponse().setComplete();
    }

    public static class Config {
    }
}

