package com.banking.auth_service.dto;

public record AuthResponse(
        String token,
        String role
) {}
