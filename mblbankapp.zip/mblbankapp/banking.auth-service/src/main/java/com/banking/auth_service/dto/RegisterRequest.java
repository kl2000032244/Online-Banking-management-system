package com.banking.auth_service.dto;

public record RegisterRequest(
        String username,
        String password
) {}
