package com.banking.auth_service.entity;

public enum Role {
    USER,
    ADMIN
}

