package com.banking.account_service.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.banking.account_service.dto.CreateAccountRequest;
import com.banking.account_service.dto.UpdateContactRequest;
import com.banking.account_service.service.AccountService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/accounts")
public class AccountController {

    private final AccountService accountService;

    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    @PostMapping
    public Object create(@RequestHeader("X-USER-ID") Long userId,
            @Valid @RequestBody CreateAccountRequest req) {
        return accountService.createAccount(req, userId);
    }

    // Secured internal endpoint for Transaction Service
    @PostMapping("/balance-update")
    public void updateBalance(@RequestHeader("X-USER-ID") Long userId,
            @org.springframework.web.bind.annotation.RequestParam Double amount) {
        accountService.updateBalance(userId, amount);
    }

    @GetMapping("/me")
    public Object myAccount(@RequestHeader("X-USER-ID") Long userId) {
        return accountService.getMyAccount(userId);
    }

    @PutMapping("/update")
    public Object updateContact(@RequestHeader("X-USER-ID") Long userId,
            @RequestBody UpdateContactRequest req) {
        return accountService.updateContactInfo(userId, req);
    }

    @DeleteMapping("/delete")
    public Object deleteAccount(@RequestHeader("X-USER-ID") Long userId) {
        accountService.deleteAccount(userId);
        return "Account deleted successfully";
    }

    @GetMapping
    public List<?> allAccounts() {
        return accountService.getAllAccounts(); // ADMIN via Gateway
    }
}
