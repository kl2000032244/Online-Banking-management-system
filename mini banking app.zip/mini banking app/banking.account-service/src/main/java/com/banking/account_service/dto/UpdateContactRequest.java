package com.banking.account_service.dto;

import jakarta.validation.constraints.NotBlank;

public class UpdateContactRequest {

    @NotBlank
    private String phone;

    private AddressDto address;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public AddressDto getAddress() {
        return address;
    }

    public void setAddress(AddressDto address) {
        this.address = address;
    }
}
