package com.banking.account_service.exception;



public class AccountAlreadyExistsException extends RuntimeException {
    public AccountAlreadyExistsException(String msg) {
        super(msg);
    }
}
