package com.banking.account_service.service;

import java.util.List;

import com.banking.account_service.dto.AccountResponse;
import com.banking.account_service.dto.CreateAccountRequest;
import com.banking.account_service.dto.UpdateContactRequest;

public interface AccountService {

    AccountResponse createAccount(CreateAccountRequest request, Long userId);

    AccountResponse getMyAccount(Long userId);

    AccountResponse updateContactInfo(Long userId, UpdateContactRequest req);

    void updateBalance(Long userId, Double amount);

    void deleteAccount(Long userId);

    List<AccountResponse> getAllAccounts(); // ADMIN
}