package com.banking.account_service.service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.banking.account_service.dto.AccountResponse;
import com.banking.account_service.dto.AddressDto;
import com.banking.account_service.dto.CreateAccountRequest;
import com.banking.account_service.dto.UpdateContactRequest;
import com.banking.account_service.entity.Account;
import com.banking.account_service.entity.Address;
import com.banking.account_service.exception.AccountAlreadyExistsException;
import com.banking.account_service.exception.ResourceNotFoundException;
import com.banking.account_service.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public AccountResponse createAccount(CreateAccountRequest req, Long userId) {

        if (accountRepository.existsByEmail(req.getEmail())) {
            throw new AccountAlreadyExistsException("Email already registered with an account");
        }

        if (accountRepository.existsByUserId(userId)) {
            throw new AccountAlreadyExistsException("User already has an account (Limit: 1)");
        }

        Account account = new Account();
        account.setAccountNumber(generateAccountNumber());
        account.setFullName(req.getFullName());
        account.setEmail(req.getEmail());
        account.setPhone(req.getPhone());
        account.setUserId(userId);
        account.setBalance(req.getInitialDeposit() != null ? req.getInitialDeposit() : 0.0);

        Address addr = new Address();
        addr.setStreet(req.getAddress().getStreet());
        addr.setCity(req.getAddress().getCity());
        addr.setState(req.getAddress().getState());
        addr.setPincode(req.getAddress().getPincode());

        account.setAddress(addr);

        accountRepository.save(account);

        return mapToResponse(account);
    }

    @Override
    public AccountResponse updateContactInfo(Long userId, UpdateContactRequest req) {
        Account account = accountRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        if (req.getPhone() != null && !req.getPhone().isBlank()) {
            account.setPhone(req.getPhone());
        }

        if (req.getAddress() != null) {
            Address addr = account.getAddress();
            if (addr == null) {
                addr = new Address();
                account.setAddress(addr);
            }
            if (req.getAddress().getStreet() != null)
                addr.setStreet(req.getAddress().getStreet());
            if (req.getAddress().getCity() != null)
                addr.setCity(req.getAddress().getCity());
            if (req.getAddress().getState() != null)
                addr.setState(req.getAddress().getState());
            if (req.getAddress().getPincode() != null)
                addr.setPincode(req.getAddress().getPincode());
        }

        accountRepository.save(account);
        accountRepository.save(account);
        return mapToResponse(account);
    }

    @Override
    public void updateBalance(Long userId, Double amount) {
        Account account = accountRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        Double currentBalance = account.getBalance() != null ? account.getBalance() : 0.0;
        account.setBalance(currentBalance + amount);

        accountRepository.save(account);
    }

    @Override
    public void deleteAccount(Long userId) {
        Account account = accountRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));
        accountRepository.delete(account);
    }

    @Override
    public AccountResponse getMyAccount(Long userId) {
        Account account = accountRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));
        return mapToResponse(account);
    }

    @Override
    public List<AccountResponse> getAllAccounts() {
        return accountRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    private String generateAccountNumber() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 12).toUpperCase();
    }

    private AccountResponse mapToResponse(Account a) {
        AccountResponse res = new AccountResponse();
        res.setAccountNumber(a.getAccountNumber());
        res.setFullName(a.getFullName());
        res.setEmail(a.getEmail());
        res.setPhone(a.getPhone());
        res.setBalance(a.getBalance());

        AddressDto dto = new AddressDto();
        dto.setStreet(a.getAddress().getStreet());
        dto.setCity(a.getAddress().getCity());
        dto.setState(a.getAddress().getState());
        dto.setPincode(a.getAddress().getPincode());

        res.setAddress(dto);
        return res;
    }
}
