package com.banking.account_service.util;



import java.util.UUID;

public class AccountNumberGenerator {

    public static String generate() {
        return UUID.randomUUID().toString()
                .replace("-", "")
                .substring(0, 12)
                .toUpperCase();
    }
}
