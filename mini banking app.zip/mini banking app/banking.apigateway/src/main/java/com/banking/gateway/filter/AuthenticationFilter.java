package com.banking.gateway.filter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import com.banking.gateway.util.JwtUtil;

import io.jsonwebtoken.Claims;
import reactor.core.publisher.Mono;

@Component
public class AuthenticationFilter
        extends AbstractGatewayFilterFactory<AuthenticationFilter.Config> {

    @Autowired
    private RouteValidator routeValidator;

    @Autowired
    private JwtUtil jwtUtil;

    public AuthenticationFilter() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {

            if (routeValidator.isSecured.test(exchange.getRequest())) {

                // 1️⃣ Check Authorization header
                if (!exchange.getRequest().getHeaders()
                        .containsKey(HttpHeaders.AUTHORIZATION)) {
                    return onError(exchange, "Missing Authorization Header");
                }

                String authHeader = exchange.getRequest()
                        .getHeaders()
                        .getFirst(HttpHeaders.AUTHORIZATION);

                if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                    return onError(exchange, "Invalid Authorization Header");
                }

                String token = authHeader.substring(7);

                try {
                    // 2️⃣ Validate token
                    jwtUtil.validateToken(token);

                    // 3️⃣ Extract claims
                    Claims claims = jwtUtil.extractClaims(token);
                    String role = claims.get("role", String.class);
                    // Integer userIdInt = claims.get("userId", Integer.class);
                    // Long userId = Long.valueOf(userIdInt);
                    // depending on how it's serialized, it might be Integer or Long. Safest to use
                    // Number.
                    Number userIdNum = claims.get("userId", Number.class);
                    if (userIdNum == null) {
                        return onError(exchange, "Invalid Token: missing userId");
                    }
                    String userId = String.valueOf(userIdNum.longValue());

                    // 4️⃣ Add ID to Header
                    exchange = exchange.mutate()
                            .request(r -> r.header("X-USER-ID", userId))
                            .build();

                    // 5️⃣ ROLE BASED ACCESS
                    // 5️⃣ ROLE BASED ACCESS
                    String path = exchange.getRequest().getURI().getPath();
                    String method = exchange.getRequest().getMethod().name();

                    // Rules:
                    // 1. /accounts/me -> Public for any Authenticated User.
                    // 2. POST /accounts -> Public (Create Account).
                    // 3. GET /accounts -> Admin Only.

                    if (path.contains("/accounts")) {
                        // Allow /accounts/me
                        if (path.contains("/accounts/me")) {
                            // OK
                        }
                        // Allow POST /accounts (Creation)
                        else if (path.equals("/accounts") && "POST".equalsIgnoreCase(method)) {
                            // OK
                        }
                        // Allow PUT /accounts/update (Update Contact)
                        else if (path.contains("/accounts/update") && "PUT".equalsIgnoreCase(method)) {
                            // OK
                        }
                        // Allow DELETE /accounts/delete (Delete Account)
                        else if (path.contains("/accounts/delete") && "DELETE".equalsIgnoreCase(method)) {
                            // OK
                        }
                        // Allow Transaction Service endpoints
                        else if (path.contains("/transactions")) {
                            // Allow all methods for now (Deposit, Withdraw, History) for authenticated
                            // users
                            // OK
                        }
                        // Block everything else (like GET /accounts) unless Admin
                        else {
                            if (!"ADMIN".equals(role)) {
                                return onError(exchange, "ADMIN access only");
                            }
                        }
                    }

                } catch (Exception e) {
                    System.err.println("Gateway Auth Error: " + e.getMessage());
                    return onError(exchange, "Invalid or expired token");
                }
            }

            return chain.filter(exchange);
        };
    }

    private Mono<Void> onError(ServerWebExchange exchange, String message) {
        exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
        return exchange.getResponse().setComplete();
    }

    public static class Config {
    }
}
