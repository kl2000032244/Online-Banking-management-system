package com.banking.transaction_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.banking.transaction_service.dto.AccountResponse;

@FeignClient(name = "banking.account-service")
public interface AccountClient {

    @GetMapping("/accounts/me")
    AccountResponse getMyAccount(@RequestHeader("X-USER-ID") Long userId);

    @PostMapping("/accounts/balance-update")
    void updateBalance(@RequestHeader("X-USER-ID") Long userId, @RequestParam Double amount);
}
