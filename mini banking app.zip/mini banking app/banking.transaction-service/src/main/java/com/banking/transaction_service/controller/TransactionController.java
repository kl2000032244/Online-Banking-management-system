package com.banking.transaction_service.controller;

import org.springframework.web.bind.annotation.*;
import com.banking.transaction_service.dto.TransactionRequest;
import com.banking.transaction_service.service.TransactionService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

    private final TransactionService transactionService;

    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @PostMapping("/deposit")
    public Object deposit(@RequestHeader("X-USER-ID") Long userId,
            @Valid @RequestBody TransactionRequest req) {
        return transactionService.deposit(userId, req);
    }

    @PostMapping("/withdraw")
    public Object withdraw(@RequestHeader("X-USER-ID") Long userId,
            @Valid @RequestBody TransactionRequest req) {
        return transactionService.withdraw(userId, req);
    }

    @GetMapping
    public Object getHistory(@RequestHeader("X-USER-ID") Long userId) {
        return transactionService.getHistory(userId);
    }
}
