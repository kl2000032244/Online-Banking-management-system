package com.banking.transaction_service.dto;


public class AccountResponse {
    private String accountNumber;
    private String fullName;
    private Double balance;
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "AccountResponse [accountNumber=" + accountNumber + ", fullName=" + fullName + ", balance=" + balance
				+ "]";
	}
    
}
