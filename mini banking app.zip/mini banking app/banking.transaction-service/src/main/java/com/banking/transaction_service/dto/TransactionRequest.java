package com.banking.transaction_service.dto;


import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;


public class TransactionRequest {

    @NotNull
    @Min(1)
    private Double amount;

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "TransactionRequest [amount=" + amount + "]";
	}
    
    
}