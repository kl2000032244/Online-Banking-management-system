package com.banking.transaction_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.banking.transaction_service.entity.Transaction;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findByUserId(Long userId);
}
