package com.banking.transaction_service.service;

import com.banking.transaction_service.dto.TransactionRequest;
import com.banking.transaction_service.entity.Transaction;
import java.util.List;

public interface TransactionService {
    Transaction deposit(Long userId, TransactionRequest request);

    Transaction withdraw(Long userId, TransactionRequest request);

    List<Transaction> getHistory(Long userId);
}
