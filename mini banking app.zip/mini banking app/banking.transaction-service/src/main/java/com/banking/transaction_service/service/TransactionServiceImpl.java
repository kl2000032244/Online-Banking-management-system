package com.banking.transaction_service.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.banking.transaction_service.client.AccountClient;
import com.banking.transaction_service.dto.AccountResponse;
import com.banking.transaction_service.dto.TransactionRequest;
import com.banking.transaction_service.entity.Transaction;
import com.banking.transaction_service.exception.InsufficientBalanceException;
import com.banking.transaction_service.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountClient accountClient;

    // Explicit constructor injection used instead of @RequiredArgsConstructor
    public TransactionServiceImpl(TransactionRepository transactionRepository, AccountClient accountClient) {
        this.transactionRepository = transactionRepository;
        this.accountClient = accountClient;
    }

    @Override
    public Transaction deposit(Long userId, TransactionRequest request) {
        // 1. Update Balance in Account Service
        // Positive amount for deposit
        accountClient.updateBalance(userId, request.getAmount());

        // 2. Save Transaction
        Transaction tx = new Transaction();
        tx.setUserId(userId);
        tx.setAmount(request.getAmount());
        tx.setType("DEPOSIT");
        return transactionRepository.save(tx);
    }

    @Override
    public Transaction withdraw(Long userId, TransactionRequest request) {
        // 1. Check Balance
        AccountResponse account = accountClient.getMyAccount(userId);
        if (account.getBalance() < request.getAmount()) {
            throw new InsufficientBalanceException("Insufficient Funds. Available: " + account.getBalance());
        }

        // 2. Update Balance in Account Service
        // Negative amount for withdraw
        accountClient.updateBalance(userId, -request.getAmount());

        // 3. Save Transaction
        Transaction tx = new Transaction();
        tx.setUserId(userId);
        tx.setAmount(request.getAmount());
        tx.setType("WITHDRAW");
        return transactionRepository.save(tx);
    }

    @Override
    public List<Transaction> getHistory(Long userId) {
        return transactionRepository.findByUserId(userId);
    }
}
