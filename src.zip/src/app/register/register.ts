import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './register.html',
  styleUrls: ['./register.css']  // <- Use register.css here
})
export class RegisterComponent {

  username = '';
  password = '';

  constructor(private router: Router) {}

  register() {
    if (!this.username || !this.password) {
      alert('Please enter username and password!');
      return;
    }

    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const exists = users.find((u: any) => u.username === this.username);

    if (exists) {
      alert('Username already exists!');
      return;
    }

    users.push({ username: this.username, password: this.password });
    localStorage.setItem('users', JSON.stringify(users));
    alert('Registration Successful!');
    this.router.navigate(['/login']);
  }
}
